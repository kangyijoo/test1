
$(function(){

 
    $(".hamburger").click(function(){
        $(".mmenu").slideDown(300);
    });

});